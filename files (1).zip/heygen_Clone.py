import requests
import time
import json
import os
from urllib.parse import urlparse

# Your API key - make sure this is valid
API_KEY = "YOUR_API_KEY_HERE"

headers = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

def create_video(text_input):
    """Create a video using HeyGen API"""

    payload = {
        "video_inputs": [
            {
                "character": {
                    "type": "avatar",
                    "avatar_id": "Daisy-inskirt-20220818"
                },
                "voice": {
                    "type": "text",
                    "input_text": text_input,
                    "voice_id": "1bd001e7e50f421d891986aad5158bc8"
                }
            }
        ],
        "test": True,  # Set to False for production videos
        "caption": False,
        "dimension": {
            "width": 1280,
            "height": 720
        }
    }

    print(f"🎬 Creating video with text: '{text_input}'")
    print("⏳ Please wait...")

    try:
        response = requests.post(
            "https://api.heygen.com/v2/video/generate",
            headers=headers,
            json=payload,
            timeout=30
        )

        if response.status_code == 200:
            data = response.json()
            if data.get('error') is None and 'data' in data and 'video_id' in data['data']:
                video_id = data['data']['video_id']
                print(f"✅ Video generation started!")
                print(f"📹 Video ID: {video_id}")
                return video_id
            else:
                print(f"❌ API Error: {data.get('error', 'Unknown error')}")
                return None
        else:
            print(f"❌ HTTP Error: {response.status_code}")
            return None

    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        return None


def get_status(video_id):
    url = f"https://api.heygen.com/v1/video_status.get?video_id={video_id}"

    headers = {
        "accept": "application/json",
        "x-api-key": "YOUR_API_KEY_HERE"
    }
    response = requests.get(url, headers=headers)
    return response


def main():
    """Main function - simple flow"""
    print("🚀 HeyGen AI Video Generator")
    print("=" * 40)
    print("Enter the text you want the AI to speak:")
    print()

    # Get text input
    text_input = input("💬 Enter text: ").strip()

    if not text_input:
        print("❌ No text provided. Exiting...")
        return

    print()

    # Create video
    video_id = create_video(text_input)
    # For testing purposes, replace with actual call
    if video_id:
        # Wait and download
        check = True
        while check:
            print("⏳ Checking video status...")
            success = get_status(video_id)
            printOutput = success.json()
            print(printOutput['message'])
            if printOutput['message'] == "Success":
                video_url = printOutput['data']['video_url']
                print(f"\n✅ Video is ready!")
                print(f"🔗 Video URL: {video_url}")

                # Extract filename from URL
                parsed_url = urlparse(video_url)
                filename = os.path.basename(parsed_url.path)

                # Download video
                print("⬇️ Downloading video...")
                video_response = requests.get(video_url)
                with open(filename, 'wb') as f:
                    f.write(video_response.content)
                print(f"✅ Video downloaded as '{filename}'")

                check = False
            time.sleep(10)  # Wait before checking status

        else:
            print("\n⏳ Video is still processing. Please check back later.")
    else:
        print("\n❌ Failed to create video")


if __name__ == "__main__":
    main()
